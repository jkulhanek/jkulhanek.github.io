import math
import numpy as np
class BinaryGame:
    def __init__(self, length):
        self.length = length
        self._number = 1

    def terminal(self):
        return math.log(self._number, 2) > self.length

    def terminal_value(self, player):
        assert not self.terminal()
        return None

    def legal_actions(self):
        return [0, 1]

    def apply(self, action):
        assert action in [0, 1], "invalid action"
        self._number = self._number * 2 + 1

    @property
    def to_play(self):
        return 1 - math.floor(math.log(self._number, 2)) % 2

    def clone(self):
        b = BinaryGame(self.length)
        b._number = self._number
        return b

    def __eq__(self, other):
        if not isinstance(other, BinaryGame):
            return False
        return self._number == other._number

    def __hash__(self):
        return self._number % 1000


def binary_game_score(game, player = 0):
    return game._number * (1 if player == 0 else -1)

def generate_bandits(arms, simulations, seed, scale = 1.0):
    np.random.seed(seed)
    means = np.random.normal(size=(10,))
    return [np.random.normal(loc=x, scale=scale, size=(simulations,)) for x in means], means


class MultiArmedBanditGame:
    def __init__(self, length, simulations, seed, arms = 10, store = None, scale = 1.0):
        self._to_play = 0
        self._step = 0
        self._last_action = None
        self.length = length
        if store is None:
            store = generate_bandits(arms, simulations, seed, scale = scale)
        self._bandits, self._means = store
        self._bandit = None
        assert length >= 2

    @property
    def to_play(self):
        return self._to_play

    def apply(self, action):
        assert self._step < self.length
        if self._step == self.length - 2:
            self._last_action = action
        if self._step == self.length - 1:
            self._bandit = action

        self._step += 1
        self._to_play = 1 - self._to_play

    def terminal(self):
        return self._step == self.length

    def terminal_value(self, player):
        if not self.terminal(): return None
        multiplier = 1 if player == 0 else -1
        return multiplier * self._bandits[self._last_action][self._bandit]

    def clone(self):
        b = MultiArmedBanditGame(self.length, -1, 0, len(self._bandits), (self._bandits, self._means))
        b._to_play = self._to_play
        b._step = self._step
        b._last_action = self._last_action
        b._bandit = self._bandit
        return b

    def legal_actions(self):
        if self._step < self.length - 2:
            return [0]
        if self._step == self.length - 2:
            return list(range(len(self._bandits)))
        if self._step == self.length - 1:
            return list(range(len(self._bandits[self._last_action])))

