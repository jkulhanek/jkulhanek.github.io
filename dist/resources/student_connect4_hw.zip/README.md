#Task 3 - Connect 4

In this task, we focus on two-player zero-sum games. We will work with the game [Connect 4](https://www.mathsisfun.com/games/connect4.html). The homework consists of two tasks. One is to implement an agent, which acts according to the minimax strategy. For this agent, a heuristic function is available, and the agent has to utilize it. We will call this agent the *DeterministicAgent* in the assignment. The second task is to implement the Monte Carlo Tree Search agent utilizing the UCT sampling strategy to solve the same problem but without the heuristic function. The second agent will be called *MonteCarloAgent*.

## Code
Before you start, you should have a Python3 interpreter ready. A virtual environment (venv) is recommended. You have to ensure all packages from the file `requirements.txt` are installed in your interpreter. If you use pip, you can install them by running `pip install -r requirements.txt`.

You are given a package containing several files. You need to implement and submit a single file named `agent.py`. In this file, there are two classes: `DeterministicAgent`, `MonteCarloAgent` with missing parts. All missing parts are marked with a `TODO` mark, and you have to implement them. 

There is another file called `test_agent.py` which contains tests that might be useful when implementing your assignment. You can extend them with your own tests. In order to run them, you need to run the following command `pytest --runslow`. We recommend you get familiar with pytest since you can filter which tests you want to be run and which not. If you run the command as follows: `pytest`, you will run only faster tests, which might be useful at the beginning. Generally, you should pass all tests before submitting your solution.

## Game Interface
The interface of all games used in this assignment either for your testing or for evaluation is as follows:
```
class Game:
    @property
    def to_play(self):
        return the number of the player whose move it is - either 0 or 1

    def apply(self, action):
        apply :action (mutating the object) and returns nothing

    def terminal(self):
        return true if the game terminated

    def terminal_value(self, player):
        let t be the final reward (usually 1)
        return None if the game had not terminated
        return t if :player won the game -t if it lost and 0 otherwise

    def clone(self):
        creates and returns a deep-copy of this instance

    def legal_actions(self):
        returns the list of available actions

    def __eq__(self, other):
        returns True if the two games are in the same state
        applying a move may change this equality!!

    def __hash__(self):
        returns the hash of the current game state
        applying a move may change this number!!
```
The important thing to keep in mind is that by applying an action, the game changes its state and therefore, may change its hash.

## DeterministicAgent
In this part of the assignment, you have to implement the missing code pieces in class `DeterministicAgent` in the file `agent.py`. The agent is given a heuristic function and the desired depth of the search tree. In the leaf nodes, the agent has to use its heuristic function to obtain the game score. Some clever pruning techniques should be utilized in order to pass the tests. Note, that the heuristic function accepts two arguments, first is the game instance and the second is the player whose score you want to compute.


There are three players implemented in the evaluation system, and you need to beat at least the worst one to get any points. Upon submitting your solution, you will get a score for each task as follows:
- 0 <= score < 0.5 if your solution was better or the same as our worst solution
- 0.5 <= score < 1 if your solution was better of the same as our middle solution
- 1 <= score if your solution was better or equal to our best solution

You can get up to 6 points from this section if your minimal score (minimal over all the tasks) is greater or equal to 1. You will get 4 points if it is greater or equal to 0.5 and 2 points if it is greater or equal to 0.

## MonteCarloAgent
In this part, you have to implement Monte Carlo Tree Search applied to 2-player zero-sum games. You will work with the same interface as before, but you will not use any heuristic function. You have to fill all missing parts of the class `MonteCarloAgent`. To help you get started, we prepared a data structure for storing your tree and also prepared methods, which we think might be useful to you. You are not required to use your structure, but the interface (public methods) of `MonteCarloAgent` has to stay the same. Discard all other methods as you see fit. You need to use UCT sampling in order to pass our evaluation. You can get 4 points if your solution was correct and 0 points otherwise.
