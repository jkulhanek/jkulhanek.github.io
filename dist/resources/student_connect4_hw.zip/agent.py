import math
import numpy
import random
from queue import deque

class Node(object):
    def __init__(self):
        self.visit_count = 0
        self.to_play = 0 
        self.value_sum = 0
        self.children = {}
        self.unexplored_actions = None
        self.is_terminal = False

    def expanded(self):
        return len(self.children) > 0 or self.is_terminal

    def fully_expanded(self):
        return self.expanded() and \
                self.unexplored_actions is not None and \
                len(self.unexplored_actions) == 0 and \
                not self.is_terminal

    def value(self):
        if self.visit_count == 0:
            return 0
        return self.value_sum / self.visit_count

class DeterministicAgent:
    def __init__(self, evaluate_fn, maximizing_player, depth):
        self.maximizing_player = maximizing_player
        self.evaluate_fn = evaluate_fn
        self.estimate_depth = depth

    def compute_estimate(self, game):
        """
        Computes the game estimate
        """
        return self.alphabeta(game, -float("inf"), float("inf"), self.estimate_depth, 1)

    def act(self, game):
        """
        Selects the best action according to its estimate
        """
        def _step_new(g, action):
            g = g.clone()
            g.apply(action)
            return g
        _, action = max(((self.compute_estimate(_step_new(game, action)), action) for action in game.valid_actions()))
        return action

    def alphabeta(self, game, alpha, beta, depth, color):
        #
        # TODO: implement
        # Your goal is to minimize the number of evaluations of the estimate function.
        #

        # Implementation hints:
        # - Note, that sort can take O(n log n). When comparing two actions, precompute the estimates of the resulting boards.
        # - In some games you can get to the same states by following different sequence of actions. Caching states can be useful.
        # - Function estimate_fn has the following form: (game, player) -> float, where :game is the game instance and :player is the player whose score you want to compute. Since the game is a zero-sum game, the other player has score of minus that value.
        return 0


class MonteCarloAgent:
    def __init__(self, num_simulations, uct_constant = math.sqrt(2)):
        self.num_simulations = num_simulations
        self.uct_constant = uct_constant

    def compute_estimate(self, game):
        """
        Computes the game estimate
        """
        root = self.mcts(game)
        return root.value_sum / root.visit_count


    def act(self, game):
        root = self.mcts(game)
        return self._select_action(root)


    def mcts(self, game):
        """
        Runs MCTS search on current game state
        """
        root = Node()
        for _ in range(self.num_simulations):
            #
            # TODO: implement
            #
            pass
        return root

    def _select_action(self, node):
        _, action = max((c.visit_count, a) for a, c in node.items())
        return action

    def _expand(self, search_path, node, game):
        """
        If the node is terminal, does nothing and returns the node.
        Otherwise, expands the node, selects a child, adds the child on the search path and returns it.
        """
        #
        # TODO: implement
        #
        pass

    def _backpropagate(self, search_path, value):
        """
        At the end of a simulation, we propagate the evaluation all the way up the
        tree to the root. We also increase the visit_count.
        :param float value: The game score relative to the last state on the search path. It could be 1 for winning player and -1 for losing player.
        """
        #
        # TODO: implement
        #
        # Note: when we backpropagate to a state with different to_play, we have to negate the result
        pass

    def _simulate(self, node, game):
        """
        We simulate one rollout starting at node :node with current game state.
        :return: terminal_value relative to the node.to_play player.
        """
        #
        # TODO: implement
        #
        pass

    def _uct_select(self, node):
        _, action, child = max((self._uct_score(node, child), action, child)
                                                  for action, child in node.children.items())
        return action, child

    def _uct_score(self, parent, child):
        """
        Computes the uct score of a given node
        """
        return 0
