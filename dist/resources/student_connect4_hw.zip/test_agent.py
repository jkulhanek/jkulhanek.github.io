#!/usr/bin/env python3
from utils import start_random, extend_game_with_counter
import math
import numpy as np
import pytest

def connect4_estimate(agent, seed, depth, random_moves):
    from connect4 import Connect4, connect4_score
    game_fn, score_fn = extend_game_with_counter(Connect4, connect4_score)
    agent = agent(score_fn, 0, depth)
    game = start_random(game_fn, random_moves, seed, assert_not_terminal=True)
    estimate = agent.compute_estimate(game)
    return estimate, game.expanded_nodes_count, game.estimated_nodes_count

def binary_game_estimate(agent, seed, depth, random_moves, game_length):
    from testing_games import BinaryGame, binary_game_score
    game_fn_o, score_fn = extend_game_with_counter(BinaryGame, binary_game_score)
    game_fn = lambda: game_fn_o(game_length)
    agent = agent(score_fn, 0, depth)
    game = start_random(game_fn, random_moves, seed)
    estimate = agent.compute_estimate(game)
    return estimate, game.expanded_nodes_count, game.estimated_nodes_count

def connect4_mean_and_std(Agent, seed, start_steps, simulations = 1000):
    from connect4 import Connect4
    estimates = []
    game = start_random(Connect4, start_steps, seed, assert_not_terminal = True)
    
    for _ in range(200):
        agent = Agent(simulations)
        estimates.append(agent.compute_estimate(game.clone()))
    return np.mean(estimates), np.std(estimates)

def stochastic_connect4_mean_and_std(Agent, seed, p, start_steps, simulations = 1000):
    from connect4 import StochasticConnect4
    estimates = []
    game_fn = lambda: StochasticConnect4(p, seed)
    game = start_random(game_fn, start_steps, seed, assert_not_terminal = True)
    
    for _ in range(200):
        agent = Agent(simulations)
        estimates.append(agent.compute_estimate(game.clone()))
    return np.mean(estimates), np.std(estimates)

ZTEST_LEVEL = 1.96 
def ztest(observed, expected):
    (m1, s1) = observed
    (m2, s2) = expected
    zstat = math.sqrt(200) * (m1 - m2) / math.sqrt(s1**2 + s2**2)
    print("mean: %.4f, std: %.4f" % observed)
    print(f"Z-statistic: {zstat}")
    return zstat

class TestMonteCarloTreeSearch:
    def test_multi_armed_1(self):
        from agent import MonteCarloAgent as Agent
        from testing_games import MultiArmedBanditGame
        simulations = 8000
        game = MultiArmedBanditGame(2, simulations, 1, scale=0.01)
        agent = Agent(simulations, 2)
        r = agent.mcts(game.clone())
        value = max(game._means)

        assert r.visit_count == simulations
        assert r.value() < value
        assert abs(value - r.value()) <= 0.09

    def test_multi_armed_2(self):
        from agent import MonteCarloAgent as Agent
        from testing_games import MultiArmedBanditGame
        simulations = 8000
        game = MultiArmedBanditGame(3, simulations, 1, scale=0.01)
        agent = Agent(simulations, 2)
        r = agent.mcts(game.clone())
        value = min(game._means)

        assert r.visit_count == simulations
        assert r.value() > value
        assert abs(value - r.value()) <= 0.09

    def test_multi_armed_3(self):
        from agent import MonteCarloAgent as Agent
        from testing_games import MultiArmedBanditGame
        simulations = 8000
        game = MultiArmedBanditGame(50, simulations, 1, scale=0.1)
        agent = Agent(simulations, 2)
        r = agent.mcts(game.clone())
        value = max(game._means)

        assert r.visit_count == simulations
        assert r.value() < value
        assert abs(value - r.value()) <= 0.09

    def test_multi_armed_4(self):
        from agent import MonteCarloAgent as Agent
        from testing_games import MultiArmedBanditGame
        simulations = 8000
        game = MultiArmedBanditGame(51, simulations, 1, scale=0.1)
        agent = Agent(simulations, 2)
        r = agent.mcts(game.clone())
        value = min(game._means)

        assert r.visit_count == simulations
        assert r.value() > value
        assert abs(value - r.value()) <= 0.09

    @pytest.mark.slow
    def test_connect4_1(self):
        from agent import MonteCarloAgent as Agent
        zstat = ztest(connect4_mean_and_std(Agent, 1, 18, simulations=2000), (-0.5683, 0.0540))
        
        assert abs(zstat) < ZTEST_LEVEL, "likely incorrect"

    @pytest.mark.slow
    def test_connect4_2(self):
        from agent import MonteCarloAgent as Agent
        zstat = ztest(connect4_mean_and_std(Agent, 1, 16, simulations=2000), (-0.5029, 0.0265))
        assert abs(zstat) < ZTEST_LEVEL, "likely incorrect"

    @pytest.mark.slow
    def test_connect4_3(self):
        from agent import MonteCarloAgent as Agent
        zstat = ztest(stochastic_connect4_mean_and_std(Agent, 1, 0.3, 18, simulations=4000), (-0.6366, 0.0555))
        assert abs(zstat) < ZTEST_LEVEL, "likely incorrect"

    @pytest.mark.slow
    def test_connect4_4(self):
        from agent import MonteCarloAgent as Agent
        zstat = ztest(stochastic_connect4_mean_and_std(Agent, 1, 0.3, 16, simulations=4000), (-0.4968, 0.0237))
        assert abs(zstat) < ZTEST_LEVEL, "likely incorrect"


class TestDeterministicAgent:
    def test_binary_game_1(self):
        from agent import DeterministicAgent as Agent
        value, _, estimated_nodes_count = binary_game_estimate(Agent, 1, 20, 2, 10000)
        assert value == 8388607 

    def test_binary_game_2(self):
        from agent import DeterministicAgent as Agent
        value, _, estimated_nodes_count = binary_game_estimate(Agent, 1, 22, 2, 10000)
        assert value == 33554431 

    def test_binary_game_3(self):
        from agent import DeterministicAgent as Agent
        value, _, estimated_nodes_count = binary_game_estimate(Agent, 1, 30, 2, 10000)
        assert value == 8589934591 

    @pytest.mark.slow
    def test_connect4_1(self):
        from agent import DeterministicAgent as Agent
        value, _, estimated_nodes_count = connect4_estimate(Agent, 1, 7, 6)
        assert value == 2900
        assert estimated_nodes_count <= 63900

    @pytest.mark.slow
    def test_connect4_2(self):
        from agent import DeterministicAgent as Agent
        value, _, estimated_nodes_count = connect4_estimate(Agent, 2, 7, 6)
        assert value == 3600
        assert estimated_nodes_count <= 46737

    @pytest.mark.slow
    def test_connect4_3(self):
        from agent import DeterministicAgent as Agent
        value, _, estimated_nodes_count = connect4_estimate(Agent, 1, 9, 6)
        assert value == 3800
        assert estimated_nodes_count <= 574614

    @pytest.mark.slow
    def test_connect4_4(self):
        from agent import DeterministicAgent as Agent
        value, _, estimated_nodes_count = connect4_estimate(Agent, 2, 9, 6)
        assert value == 3500
        assert estimated_nodes_count <= 499871
